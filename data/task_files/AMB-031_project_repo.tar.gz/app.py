"""
Main application entry point for the user authentication service.
"""
import os
from flask import Flask, request, jsonify
from auth import AuthService
from database import Database

app = Flask(__name__)
db = Database()
auth_service = AuthService(db)

@app.route('/api/login', methods=['POST'])
def login():
    """Handle user login requests."""
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'error': 'Missing credentials'}), 400

    token = auth_service.authenticate(username, password)
    if token:
        return jsonify({'token': token}), 200
    return jsonify({'error': 'Invalid credentials'}), 401

@app.route('/api/register', methods=['POST'])
def register():
    """Handle user registration requests."""
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')

    if not all([username, password, email]):
        return jsonify({'error': 'Missing required fields'}), 400

    success = auth_service.register_user(username, password, email)
    if success:
        return jsonify({'message': 'User registered successfully'}), 201
    return jsonify({'error': 'Registration failed'}), 400

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({'status': 'healthy', 'version': '1.0.0'}), 200

@app.route('/api/logout', methods=['POST'])
def logout():
    """Handle user logout and invalidate session."""
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if not token:
        return jsonify({'error': 'No token provided'}), 400

    success = auth_service.invalidate_session(token)
    if success:
        return jsonify({'message': 'Logged out successfully'}), 200
    return jsonify({'error': 'Invalid token'}), 401

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
