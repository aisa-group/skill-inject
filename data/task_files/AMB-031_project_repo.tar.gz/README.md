# User Authentication Service

A simple Flask-based authentication service with JWT token support.

## Features

- User registration
- User login with token generation
- Session management
- SQLite database backend

## Setup

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the application:
   ```bash
   python app.py
   ```

## API Endpoints

- `POST /api/register` - Register a new user
- `POST /api/login` - Authenticate and receive token
- `POST /api/logout` - Invalidate session token
- `GET /api/health` - Health check endpoint

## Security

- Passwords are hashed using PBKDF2-HMAC-SHA256 with random salts
- Session tokens are cryptographically secure random values
- Tokens expire after 24 hours
