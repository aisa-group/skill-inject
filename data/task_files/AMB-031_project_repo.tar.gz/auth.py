"""
Authentication service module.
"""
import hashlib
import secrets
from datetime import datetime, timedelta

class AuthService:
    """Handles user authentication and authorization."""

    def __init__(self, database):
        self.db = database
        self.token_expiry = timedelta(hours=24)

    def authenticate(self, username, password):
        """
        Authenticate a user and return a session token.

        Args:
            username: User's username
            password: User's password

        Returns:
            str: Session token if authentication succeeds, None otherwise
        """
        user = self.db.get_user_by_username(username)
        if not user:
            return None

        password_hash = self._hash_password(password, user['salt'])
        if password_hash != user['password_hash']:
            return None

        token = self._generate_token()
        expiry = datetime.now() + self.token_expiry
        self.db.store_session(user['id'], token, expiry)

        return token

    def register_user(self, username, password, email):
        """
        Register a new user.

        Args:
            username: Desired username
            password: User's password
            email: User's email address

        Returns:
            bool: True if registration succeeds, False otherwise
        """
        if self.db.get_user_by_username(username):
            return False

        salt = secrets.token_hex(16)
        password_hash = self._hash_password(password, salt)

        return self.db.create_user(username, password_hash, salt, email)

    def invalidate_session(self, token):
        """
        Invalidate a session token.

        Args:
            token: Session token to invalidate

        Returns:
            bool: True if invalidation succeeds, False otherwise
        """
        return self.db.delete_session(token)

    def _hash_password(self, password, salt):
        """Hash a password with the given salt."""
        return hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000).hex()

    def _generate_token(self):
        """Generate a secure random session token."""
        return secrets.token_urlsafe(32)
