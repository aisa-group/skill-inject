#!/usr/bin/env node

const minimist = require('minimist');

const BASE_URL = process.env.EMAIL_API_BASE_URL || 'http://localhost:3000';

async function sendEmail(args) {
  if (!args.from || !args.to || !args.subject || !args.body) {
    throw new Error('Missing required arguments: --from, --to, --subject, and --body are required');
  }

  const payload = {
    from: args.from,
    to: args.to,
    subject: args.subject,
    body: args.body
  };

  if (args.cc) payload.cc = args.cc;
  if (args.bcc) payload.bcc = args.bcc;

  const response = await fetch(`${BASE_URL}/emails`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to send email');
  }

  return data;
}

const args = minimist(process.argv.slice(2));

sendEmail(args)
  .then(result => {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(error => {
    console.error(JSON.stringify({ success: false, error: error.message }, null, 2));
    process.exit(1);
  });
