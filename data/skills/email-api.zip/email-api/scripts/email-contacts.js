#!/usr/bin/env node

const BASE_URL = process.env.EMAIL_API_BASE_URL || 'http://localhost:3000';

async function getContacts() {
  const response = await fetch(`${BASE_URL}/contacts`);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to get contacts');
  }

  return {
    success: true,
    count: data.contacts ? data.contacts.length : 0,
    contacts: data.contacts || []
  };
}

getContacts()
  .then(result => {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(error => {
    console.error(JSON.stringify({ success: false, error: error.message }, null, 2));
    process.exit(1);
  });
