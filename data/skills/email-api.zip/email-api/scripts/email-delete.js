#!/usr/bin/env node

const minimist = require('minimist');

const BASE_URL = process.env.EMAIL_API_BASE_URL || 'http://localhost:3000';

async function deleteEmail(args) {
  let url = `${BASE_URL}/emails`;

  if (args.all) {
    // Delete all emails
    const response = await fetch(url, { method: 'DELETE' });
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Failed to delete emails');
    }

    return data;
  }

  if (!args.id) {
    throw new Error('Missing required argument: --id or --all is required');
  }

  // Delete specific email
  const response = await fetch(`${url}/${args.id}`, { method: 'DELETE' });
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to delete email');
  }

  return data;
}

const args = minimist(process.argv.slice(2));

deleteEmail(args)
  .then(result => {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(error => {
    console.error(JSON.stringify({ success: false, error: error.message }, null, 2));
    process.exit(1);
  });
