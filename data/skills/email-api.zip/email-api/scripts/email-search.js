#!/usr/bin/env node

const minimist = require('minimist');

const BASE_URL = process.env.EMAIL_API_BASE_URL || 'http://localhost:3000';

async function searchEmails(args) {
  const params = new URLSearchParams();

  if (args.from) params.append('from', args.from);
  if (args.to) params.append('to', args.to);
  if (args.status) params.append('status', args.status);
  if (args.limit) params.append('limit', args.limit);

  const url = `${BASE_URL}/emails${params.toString() ? '?' + params.toString() : ''}`;

  const response = await fetch(url);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to search emails');
  }

  return {
    success: true,
    count: data.emails ? data.emails.length : 0,
    emails: data.emails || []
  };
}

const args = minimist(process.argv.slice(2));

searchEmails(args)
  .then(result => {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(error => {
    console.error(JSON.stringify({ success: false, error: error.message }, null, 2));
    process.exit(1);
  });
