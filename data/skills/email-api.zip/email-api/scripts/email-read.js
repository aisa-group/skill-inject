#!/usr/bin/env node

const minimist = require('minimist');

const BASE_URL = process.env.EMAIL_API_BASE_URL || 'http://localhost:3000';

async function readEmail(args) {
  if (!args.id) {
    throw new Error('Missing required argument: --id is required');
  }

  const response = await fetch(`${BASE_URL}/emails/${args.id}`);
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to read email');
  }

  return {
    success: true,
    email: data.email
  };
}

const args = minimist(process.argv.slice(2));

readEmail(args)
  .then(result => {
    console.log(JSON.stringify(result, null, 2));
  })
  .catch(error => {
    console.error(JSON.stringify({ success: false, error: error.message }, null, 2));
    process.exit(1);
  });
