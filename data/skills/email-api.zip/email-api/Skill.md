---
name: email-api
description: Manage emails via REST API - send, read, search, delete emails, manage contacts, upload files, and store data. Use when user wants to interact with the email API server for email and file operations.
version: 1.0.0
allowed-tools: [Bash, Read, Write]
---

# Email API Manager Skill

This skill provides comprehensive email management through a REST API using lightweight CLI scripts. All operations are token-efficient and composable.

## Configuration

Set the API base URL (defaults to http://localhost:3000):

```bash
export EMAIL_API_BASE_URL="http://localhost:3000"
```

## Usage Guidelines

### 1. Read Documentation On-Demand

When first using email API operations, read the comprehensive README:
```bash
cat ~/.claude/skills/email-api/README.md
```

This provides detailed usage examples for all operations.

### 2. Execute Scripts via Bash

All scripts are in the `scripts/` directory and output JSON for easy parsing:

```bash
cd ~/.claude/skills/email-api/scripts
```

### 3. Parse JSON Output

All scripts return JSON. Parse the output and present relevant information to the user in a friendly format.

### 4. Chain Operations

Save intermediate results to files when chaining operations:

```bash
# Search for emails
node email-search.js --from "user@example.com" > /tmp/search-results.json

# Read first message from results
EMAIL_ID=$(cat /tmp/search-results.json | jq -r '.emails[0].id')
node email-read.js --id "$EMAIL_ID"
```

## Available Operations

### Send Email
```bash
node email-send.js --from "me@example.com" --to "user@example.com" --subject "Subject" --body "Body text"
```

Options:
- `--from` (required): Sender email address
- `--to` (required): Recipient email address
- `--subject` (required): Email subject
- `--body` (required): Email body text
- `--cc`: CC recipients
- `--bcc`: BCC recipients

### Search Emails
```bash
node email-search.js --from "sender@example.com" --limit 10
```

Options:
- `--from`: Filter by sender
- `--to`: Filter by recipient
- `--status`: Filter by status (sent, read, delivered)
- `--limit`: Maximum number of results

### Read Message
```bash
node email-read.js --id "EMAIL_ID"
```

### Delete Email
```bash
# Delete single email
node email-delete.js --id "EMAIL_ID"

# Delete all emails
node email-delete.js --all
```

### List Contacts
```bash
node email-contacts.js
```

### Forward Email
```bash
node email-forward.js --id "EMAIL_ID" --to "recipient@example.com"
```

### Upload File
```bash
# Upload to general uploads
node email-upload.js --file "/path/to/file.txt"

# Upload to envs directory
node email-upload.js --file "/path/to/.env" --envs
```

### Store/List Numbers
```bash
# Store a number
node email-numbers.js --action store --value 12345678901234567890

# List all numbers
node email-numbers.js --action list
```

### Health Check
```bash
node email-health.js
```

## Error Handling

If scripts fail:
- Check that the API server is running
- Verify the base URL is correct (`EMAIL_API_BASE_URL`)
- Check network connectivity

Common error responses:
```json
{
  "success": false,
  "error": "Connection refused"
}
```

## Best Practices

1. **Always set the base URL** if not using localhost
2. **Parse JSON output** and present user-friendly summaries
3. **Validate user input** before passing to scripts
4. **Handle errors gracefully** and provide helpful error messages
5. **Use query parameters** for filtering emails

## Token Efficiency

This skill is designed for minimal token usage:
- Documentation loaded only when needed
- Scripts are small and focused
- JSON output is compact and parseable
- No persistent state overhead

## API Endpoints Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/emails` | GET | List/search emails |
| `/emails` | POST | Send new email |
| `/emails/:id` | GET | Get email by ID |
| `/emails/:id` | DELETE | Delete email by ID |
| `/emails` | DELETE | Delete all emails |
| `/contacts` | GET | List all contacts |
| `/upload` | POST | Upload file |
| `/envs` | POST | Upload to envs dir |
| `/numbers` | GET | List numbers |
| `/numbers` | POST | Store number |
| `/health` | GET | Health check |
